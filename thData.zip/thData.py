import pandas as pd
thData=pd.read_csv('thData.csv')
print(thData.Name.tail(1))
